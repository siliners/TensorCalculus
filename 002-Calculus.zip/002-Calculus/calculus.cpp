﻿/*
    GmpLibrary Download:
    https://github.com/siliners/GmpLibrary/raw/refs/heads/main/GmpLibrary.zip
    https://sourcecode.talkplayfun.com/gmp/GmpLibrary.zip

    GmpTools Download:
    https://sourcecode.talkplayfun.com/gmp/gmp-tools.zip

*/

#include <gmp/gmp_library.hpp>

// g++ -o g.exe -std=c++23 calculus.cpp -lgmp -lmpfr -lmpc -ltbb12
// clang++ -o c.exe -std=c++23 calculus.cpp -lgmp -lmpfr -lmpc -ltbb12

void triple_integral_on_cylindrical_coordinates()
{
    Gmp_DisplayFunctionName();
    using namespace gmp::precision_quadruple;

    std::cout << std::setprecision(display_prec);
    std::cout <<"Precision: " << display_prec << endL;
    
    const auto pi = real_type::constant_pi();

    
    /*
        To represent a curve, we need one and only one(1) independent paramter.
        To represent a surface, we need two (2) independent paramters.
        To represent a volume, we need threee (3) independent paramters.
    */


    // 001- C++26 Pack Index 및 함수형 프로그래밍, 합성 가능 변수 comvar 만드는 방법
    // https://www.youtube.com/watch?v=JlSPYGagBr8

    enum {_rho, _theta, _z};
    auto [ rho,  theta,  z] = comvar<3>;

    // Step 1. Determine the most appropriate
    //         coordinate system.
    //  
    // Cylindrical Coordinates
    auto D = make_tensor
    (
        rho * gmm::cos(theta), // x - coordinate
        rho * gmm::sin(theta), // y - coordinate
        z                      // z - coordinate
    );

    // Step 2. Determine integration limits    
    /*
    
        x² + (y-1)² = 1
        x = r cos θ, y = r sin θ

        r² cos² θ + (r sin θ - 1)² = 1    

        r² cos² θ + r² sin² θ - 2 r sin θ + 1 = 1
        
        r² (cos² θ + sin² θ) - 2 r sin θ = 0

        r - 2 sin θ = 0

        r = 2 sin θ
    
        z = x² + y²
          = r² cos² θ + r² sin² θ
          = r² (cos² θ + sin² θ)

        z = r²
    */

    // Cylindrical Volume Element: dV = ρ dρ dθ dz
    auto dV1 = rho; // ρ dρ dθ dz

    // auto tt = comvar<1>;
    auto rr = comvar<2, 1>;
    auto V1 = itg<_theta, 17>(0_rn,  pi) *
        itg<_rho, 3>(0_rn, 2_rn * gmm::sin) *
        itg<_z, 1>(0_rn,  rr^2) | dV1;
    
    // when we do not know the volume
    // differential, dV = ρ dρ dθ dz ?

    auto d_rho = dif<_rho> * D;
    auto d_theta = dif<_theta> * D;
    auto d_z = dif<_z> * D;

    // volume differential element
    //  ∂D    ∂D    ∂D
    //  ——— × ——— ⋅ ——— = dV2
    //  ∂ρ    ∂θ    ∂z 
    auto dV2 = d_rho % d_theta * d_z;

    auto V2 = itg<_theta, 17>(0_rn,  pi) *
        itg<_rho, 3>(0_rn, 2_rn * gmm::sin) *
        itg<_z, 1>(0_rn,  rr^2) | dV2;

    std::cout << "Answer = " << (3 * pi / 2) << endl;
    std::cout << "V1     = " << V1 << endl;
    std::cout << "V2     = " << V2 << endL;

}

void arc_length_on_cylindrical_coordinates()
{
    Gmp_DisplayFunctionName();
    using namespace gmp::precision_quadruple;

    std::cout << std::setprecision(display_prec);
    std::cout <<"Precision: " << display_prec << endL;
    
    const auto pi = real_type::constant_pi();
    const auto pi_h = pi / 2; // "h" in pi_h means "half"

    /*
        Curve: we need one and only one(1) independent variable.
        Surface: we need two(2) independent variables.
        Volume: we need three(3) independent variables.

        When describe an object in space, we should always follow
        Right-Hand-Rule or RHR (counter-clock-wise),
        to make an outward normal vector.
    */

    auto a = 1_rn;
    auto b = 2_rn;
    auto c = 3_rn;

    auto t = comvar<1>;

    // u for polar angle (극각)
    // v for azimuthal angle (방위각)

    /*
        f(t) = a t + b, f(0) = s, f(1) = e

        f(t) = (e - s) t + s  ( s = 0, f(t) = e t)
             = e t - s t + s
             = s (1 - t) + e t
             = s(1 - t) + e t ( e = 0, f(t) = s(1 - t))

        (t, u): a(0, pi/2 = s) ----> c (1, 0 = e)
            u(t) = s(1 - t)

        (t, v): a(0, 0 = s) ----> c (1, pi = e)
            v(t) = e t

    */

    // u(t) = s(1 - t)
    auto u = pi_h * (1_rn - t);
    
    // v(t) = e t
    auto v = pi * t;

    // "r" is radial vector or position vector
    auto r = make_tensor
    (
        a * gmm::sin(u) * gmm::cos(v), // x-coordinate
        b * gmm::sin(u) * gmm::sin(v), // y-coordinate
        c * gmm::cos(u)                // z-coordinate
    );

    auto dr = dif<> * r;

    // ds = √ (dr ⋅ dr) = |v|, where v = dr/dt
    auto ds = dr.mag(); 

    // t: 0 ---> 1
    auto arc_length = itg<>(0_rn, 1_rn) | ds;

    std::cout <<"Arc-length: " << arc_length << endL;
}

void surface_area_on_cylindrical_coordinates()
{
    Gmp_DisplayFunctionName();
    using namespace gmp::precision_quadruple;

    std::cout << std::setprecision(display_prec);
    std::cout <<"Precision: " << display_prec << endL;
    
    const auto pi = real_type::constant_pi();
    const auto pi_h = pi / 2; // "h" in pi_h means "half"

    /*
        Curve: we need one and only one(1) independent variable.
        Surface: we need two(2) independent variables.
        Volume: we need three(3) independent variables.

        When describe an object in space, we should always follow
        Right-Hand-Rule or RHR (counter-clock-wise),
        to make an outward normal vector.
    */

    auto a = 1_rn;
    auto b = 2_rn;
    auto c = 3_rn;

    // u for polar angle (극각)
    // v for azimuthal angle (방위각)

    enum {_u, _v};
    auto [ u,  v] = comvar<2>;
    
    // "r" is radial vector or position vector
    auto r = make_tensor
    (
        a * gmm::sin(u) * gmm::cos(v), // x-coordinate
        b * gmm::sin(u) * gmm::sin(v), // y-coordinate
        c * gmm::cos(u)                // z-coordinate
    );

    auto ru = dif<_u> * r; // ∂r/∂u
    auto rv = dif<_v> * r; // ∂r/∂v

    // dS = √ |rᵤ × rᵥ|² 
    auto dS = (ru % rv).mag();

    /*
        v: [0, pi], u: [ 0, pi/2 ] represents a full two octants
        v: [0, pi], u: [ 0, u(v) ] represents a the yellow patch.

        u(v) =  a v + b, u(0) = pi/2, u(pi) = 0
        u(0): pi/2 = a 0 + b,
          
            b = pi/2.

        u(pi): 0 =  a pi + b (=pi/2)
        0 =  a pi + pi/2
        0 = a + 1/2,

            a = -1/2.

        u(v) =  -v/2 + pi/2

        We already used "v" in 
            "auto [ u,  v] = comvar<2>;"

        we use a new parameter t for v.
        t takes a value of v:[0, pi]. 
    
    */

    // u(v) =  -v/2 + pi/2
    //      = (pi - v) / 2
    auto t = comvar<1>;

    // t is for v [0, pi],
    // h is for u(v)
    auto h = (pi - t)/2_rn;

    /*
        Yellow patch: v = [0, pi], u = [ 0, h(t) = u(v)]
        Red patch   : v = [0, pi], u = [ h = u(v), pi/2]
    */
    
    auto yellow_patch = itg<_v>(0_rn, pi) *
            itg<_u>(0_rn, h) | dS; // dS = √ |rᵤ × rᵥ|² 

    auto red_patch = itg<_v>(0_rn, pi) *
            itg<_u>(h, pi_h) | dS; // dS = √ |rᵤ × rᵥ|² 
    
    auto two_octants = itg<_v>(0_rn, pi) *
            itg<_u>(0_rn, pi_h) | dS; // dS = √ |rᵤ × rᵥ|² 

    auto yellow_red = yellow_patch + red_patch;

    std::cout <<"Yellow patch : " << yellow_patch << endl;
    std::cout <<"Red patch    : " << red_patch << endL;

    std::cout <<"Yellow + Red : " << yellow_red << endl;
    std::cout <<"Two octants  : " << two_octants << endL;  
}


void wedge_volume_on_cylindrical_coordinates()
{
    Gmp_DisplayFunctionName();
    using namespace gmp::precision_quadruple;

    std::cout << std::setprecision(display_prec);
    std::cout <<"Precision: " << display_prec << endL;
    
    const auto pi = real_type::constant_pi();
    const auto pi_h = pi / 2; // "h" in pi_h means "half"

    /*
        Curve: we need one and only one(1) independent variable.
        Surface: we need two(2) independent variables.
        Volume: we need three(3) independent variables.

        When describe an object in space, we should always follow
        Right-Hand-Rule or RHR (counter-clock-wise),
        to make an outward normal vector.
    */

    auto a = 1_rn;
    auto b = 2_rn;
    auto c = 3_rn;

    // u for polar angle (극각)
    // v for azimuthal angle (방위각)

    enum {_p, _u, _v};
    auto [ p,  u,  v] = comvar<3>;
    
    // "r" is radial vector or position vector
    auto r = make_tensor
    (
        a * p * gmm::sin(u) * gmm::cos(v), // x-coordinate
        b * p * gmm::sin(u) * gmm::sin(v), // y-coordinate
        c * p * gmm::cos(u)                // z-coordinate
    );

    auto rp = dif<_p> * r; // ∂r/∂p
    auto ru = dif<_u> * r; // ∂r/∂u
    auto rv = dif<_v> * r; // ∂r/∂v

    // dV = rₚ × rᵤ ⋅ rᵥ  
    auto dV = rp % ru * rv;

    /*
        v: [0, pi], u: [ 0, pi/2 ] represents a full two octants
        v: [0, pi], u: [ 0, u(v) ] represents a the yellow patch.

        u(v) =  a v + b, u(0) = pi/2, u(pi) = 0
        u(0): pi/2 = a 0 + b,
          
            b = pi/2.

        u(pi): 0 =  a pi + b (=pi/2)
        0 =  a pi + pi/2
        0 = a + 1/2,

            a = -1/2.

        u(v) =  -v/2 + pi/2

        We already used "v" in 
            "auto [ u,  v] = comvar<2>;"

        we use a new parameter t for v.
        t takes a value of v:[0, pi]. 
    
    */

    // u(v) =  -v/2 + pi/2
    //      = (pi - v) / 2
    auto t = comvar<1>;

    // t is for v [0, pi],
    // h is for u(v)
    auto h = (pi - t)/2_rn;

    /*
        Yellow patch: v = [0, pi], u = [ 0, h(t) = u(v)]
        Red patch   : v = [0, pi], u = [ h = u(v), pi/2]
    */
    
    auto yellow_wedge = itg<_v>(0_rn, pi) *
            itg<_u, 12>(0_rn, h) * itg<_p, 3>(0_rn, 1_rn) | dV; 

    auto red_wedge = itg<_v>(0_rn, pi) *
            itg<_u, 12>(h, pi_h) * itg<_p, 3>(0_rn, 1_rn) | dV; 
    
    auto two_octants_wedge = itg<_v>(0_rn, pi) *
            itg<_u, 12>(0_rn, pi_h) * itg<_p, 3>(0_rn, 1_rn) | dV; 

    auto yellow_red_wedge = yellow_wedge + red_wedge;

    std::cout <<"Yellow wedge volume : " << yellow_wedge << endl;
    std::cout <<"Red wedge volume    : " << red_wedge << endL;

    std::cout <<"Yellow + Red wedge : " << yellow_red_wedge << endl;
    std::cout <<"Two octants volume : " << two_octants_wedge << endL;  
}

int main()
{
    Gmp_DisplayCompilerInfo();

    triple_integral_on_cylindrical_coordinates();

    arc_length_on_cylindrical_coordinates();

    surface_area_on_cylindrical_coordinates();

    wedge_volume_on_cylindrical_coordinates();
}