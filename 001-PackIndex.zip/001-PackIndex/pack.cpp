﻿#include <iostream>
#include <utility>
#include <tuple>
#include <cmath>
#include <complex>
#include <numbers>

// clang++ -std=c++26 pack.cpp -o c.exe
// g++ -std=c++26 pack.cpp -o g.exe

template<auto N> //int, long long, unsigned long long 
auto gen_lambda()
{
    // auto&& is called forwarding reference,
    // which can bind to any value category (lvalue, rvalue, etc.)
    // & means memory is shared between the caller and the lambda,
    // so changes to the captured variables will be visible outside the lambda.
    // performance degrades when using auto&& in a lambda capture,
    // because it prevents certain optimizations and may require additional memory allocations.
    // In parallel algorithms, using auto&& in a lambda capture can lead to
    // data races and undefined behavior if multiple threads access the captured variables simultaneously.
    
    return [](auto... args) 
    {
        // args... is a parameter pack that can accept a variable number of arguments.
        // args...[N] is a fold expression that
        // expands the parameter pack and accesses the N-th element of the pack.
        // this feature is introduced in C++26.
        //
        // https://en.cppreference.com/cpp/language/pack_indexing
        // https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2023/p2662r3.pdf

        return args...[(std::size_t)N];
    };
}

template<auto N>
auto gen_comvar()
{
    return []<auto... n>(std::index_sequence<n...>) 
    {
        return std::tuple{ gen_lambda<n>()... };   

    }( std::make_index_sequence<(std::size_t)N>{} );
}

template<auto N>
auto comvar = gen_comvar<N>();

auto eval(auto f, auto... args)
{
    if constexpr (std::is_invocable_v<decltype(f), decltype(args)...>) 
    {
       return f(args...);
    }
     else 
    {
        return f; 
    }  
}

auto operator+(auto f, auto g)
{
    return [f, g](auto... args) 
    {
        return eval(f, args...) + eval(g, args...);
    };
}

auto operator-(auto f, auto g)
{
    return [f, g](auto... args) 
    {
        return eval(f, args...) - eval(g, args...);
    };
}

//                3.5 * x
auto operator*(auto f, auto g)
{
    return [f, g](auto... args) 
    {
        return eval(f, args...) * eval(g, args...);
    };
}

auto operator/(auto f, auto g)
{
    return [f, g](auto... args) 
    {
        return eval(f, args...) / eval(g, args...);
    };
}

template<typename T>
using complex_type = std::complex<T>;

void test_comvar() 
{
    /*
        comvar<N> generates a tuple of N lambda functions,
        where each lambda function takes a variable number
        of arguments and returns the N-th argument from the parameter pack.
        It is composable as you will see it later.
    */
    auto [x, y, z] = comvar<3>;

    std::cout <<"x = " << x(1, 2, 3) << std::endl; // Output: 1
    std::cout <<"y = " << y(1, 2, 3) << std::endl; // Output: 2
    std::cout <<"z = " << z(1, 2, 3) << std::endl; // Output: 3

    auto fp = x + y + z; 
    auto fm = x - y - z; 
    auto ft = x * y * z;
    auto fd = x / y / z;

    std::cout <<"fp = " << fp(1, 2, 3) << std::endl; // Output: 6
    std::cout <<"fm = " << fm(1, 2, 3) << std::endl; // Output: -4
    std::cout <<"ft = " << ft(1, 2, 3) << std::endl; // Output: 6
    std::cout <<"fd = " << fd(1.0, 2.0, 3.0) << std::endl; // Output: 0.166667

    using cplx_d = complex_type<double>;
    
    auto a = cplx_d{1.0, 2.0};
    auto b = cplx_d{3.0, 4.0};
    auto c = cplx_d{3.0, 4.0};

    std::cout <<"fp = " << fp(a, b, c) << std::endl; 
    std::cout <<"fm = " << fm(a, b, c) << std::endl; 
    std::cout <<"ft = " << ft(a, b, c) << std::endl; 
    std::cout <<"fd = " << fd(a, b, c) << std::endl; 

    auto fukup = (3.5 * x + 2.5 * y - 1.5 * z)/4;

    // Output: 3.5*1 + 2.5*2 - 1.5*3 = 3.5 + 5 - 4.5 = 1
    std::cout <<"fukup = " << fukup(1.0, 2.0, 3.0) << std::endl; 
}

int main() 
{   
    test_comvar();
}
