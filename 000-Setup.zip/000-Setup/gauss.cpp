﻿/*
    C++ GMP Library
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary-2025-11-02.zip

    cl curvature.cpp /Fe: m.exe /std:c++latest /EHsc /nologo
    g++ curvature.cpp -o g.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    clang++ curvature.cpp -o c.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    icx-cl curvature.cpp -o i.exe -Qstd=c++23 /nologo

    (SETUP) 가우스 곡률 1, Gaussian Curvature, Differential Geometry
    https://www.youtube.com/watch?v=weTczUZOeXY&list=PLsIvhalfft1Hq4DlHuV2XGk7CDG8GY8nt
*/

#include <gmp/gmp_library.hpp>
using namespace gmp::precision_quadruple;

void curvature_of_sphere()
{
    Gmp_DisplayFunctionName();

    const auto pi = real_type::constant_pi();

    enum {_u, _v};
    auto [ u,  v] = comvar<2>;

    auto R = 2_rn; // _rn literal of type real_type

    // u - polar angle → 극각(極角)
    // v - azimuthal angle → 방위각(方位角)

    // xyz - RHR - Right Hand Rule
    // ruv - RHR - Right Hand Rule,
    //      (radial distance, polar angle, azimuthal angle)
    //      (radial distance, azimuthal angle, polar angle) - LHR

    // r is a position vector on the surface
    // this r represents a surface

    auto r = make_tensor( 
        R * gmm::sin(u) * gmm::cos(v), // x-coord
        R * gmm::sin(u) * gmm::sin(v), // y-coord
        R * gmm::cos(u)                // z-coord
      );

    // 𝐫ᵤ = ∂𝐫/∂𝑢
    auto ru = dif<_u> * r;

    // 𝐫ᵥ = ∂𝐫/∂𝑣
    auto rv = dif<_v> * r;

    // 𝐍 = 𝐫ᵤ × 𝐫ᵥ - normal to the surface 𝐫
    auto N = ru % rv ;
    auto n = N.unit(); // 𝐧 = 𝐍 / |𝐍|, unit normal to the surface

    /*
      d𝑆 = |N| d𝑢 d𝑣
         = √(|𝐫ᵤ × 𝐫ᵥ|²) d𝑢d𝑣

      1. First Fundamental Form
         - How to measure distance on the surface

      d𝑠² = ̇𝐫 ⋅ ̇𝐫 = 𝐯 ⋅ 𝐯 = |𝐯|² 
       
      if 𝑢 = 𝑢(𝑡), 𝑣 = 𝑣(𝑡),

           d𝐫     ∂𝐫  d𝑢     ∂𝐫  d𝑣
      𝐯 = ———— = ——— ——— +  ——— ———
           d𝑡     ∂𝑢  d𝑡     ∂𝑣  d𝑡

     ̇𝐫 = 𝐯, 

             d𝑢        d𝑣
      𝐯 = 𝐫ᵤ ——— +  𝐫ᵥ ———
             d𝑡        d𝑡

    d𝑠² = ̇𝐫 ⋅ ̇𝐫 = 𝐯 ⋅ 𝐯
       
       = (𝐫ᵤ ⋅ 𝐫ᵤ) d𝑢² + 2 (𝐫ᵤ ⋅ 𝐫ᵥ) d𝑢 d𝑣 + (𝐫ᵥ ⋅ 𝐫ᵥ) d𝑣² 
       =     E    d𝑢² + 2  F       d𝑢 d𝑣 +  G        d𝑣² 

       E = 𝐫ᵤ ⋅ 𝐫ᵤ, F = 𝐫ᵤ ⋅ 𝐫ᵥ, G = 𝐫ᵥ ⋅ 𝐫ᵥ 
    */
    auto E = ru * ru; // 𝐫ᵤ ⋅ 𝐫ᵤ
    auto F = ru * rv; // 𝐫ᵤ ⋅ 𝐫ᵥ
    auto G = rv * rv; // 𝐫ᵥ ⋅ 𝐫ᵥ

    /*
      Area² = |𝐀 × 𝐁|² = |𝐫ᵤ × 𝐫ᵥ|²
            = (𝐀 × 𝐁) ⋅ (𝐀 × 𝐁)
            = (A ⋅ A)(𝐁 ⋅ 𝐁) - (𝐀 ⋅ 𝐁)(𝐀 ⋅ 𝐁)
            = (𝐫ᵤ ⋅ 𝐫ᵤ)(𝐫ᵥ ⋅ 𝐫ᵥ) - (𝐫ᵤ ⋅ 𝐫ᵥ)(𝐫ᵤ ⋅ 𝐫ᵥ)
            =  EG - F² 
    */

    // Area² = |𝐫ᵤ × 𝐫ᵥ|² d𝑢²d𝑣²
    auto dS2 = E * G - (F^2); // d𝑢²d𝑣² is omitted
    
    /*
     ====================== curve ============  
       ̇𝐫 = 𝐯,
       ̈𝐫 = 𝐚
       
       𝐚 = aₜ 𝐓 + aₙ 𝐍 ( if aₙ = 0, then linear motion )
 
                                   |𝐯|²      
       centripetal acceleration = ———— = aₙ
                                    𝜌  

      curvature 𝜅 ≠ 0, 𝜌 ≠ ∞, aₙ ≠ 0 
    
      𝜅 = 1 / 𝜌

      𝐚 ⋅ 𝐍 = aₜ 𝐓 ⋅ 𝐍 + aₙ 𝐍 ⋅ 𝐍
      𝐚 ⋅ 𝐍 = aₜ 0 + aₙ 1
      aₙ = 𝐚 ⋅ 𝐍, if aₙ = 0,

      then 𝐚 = aₜ 𝐓 + aₙ 0, 𝐚 = aₜ 𝐓, there is no curvature

    ================== surface ================

             d𝑢        d𝑣
      𝐯 = 𝐫ᵤ ——— +  𝐫ᵥ ———
             d𝑡        d𝑡

           d𝐯     d       d𝑢        d𝑣
      𝐚 = ———— = ——— { 𝐫ᵤ ——— +  𝐫ᵥ ——— }  
           d𝑡     d𝑡       d𝑡        d𝑡

              d𝑢²     d𝑣²           d𝑢           d𝑢  d𝑣          d𝑣
        =  𝐫ᵤ———— + 𝐫ᵥ————  + 𝐫ᵤᵤ (————)² + 2𝐫ᵤᵥ ——— ———— + 𝐫ᵥᵥ (————)²
              d𝑡²      d𝑡²          d𝑡            d𝑡  d𝑡           d𝑡

        = { 𝐫ᵤ ̈𝑢  + 𝐫ᵥ ̈𝑣ᵥ } + { 𝐫ᵤᵤ ̇𝑢² + 2𝐫ᵤᵥ ̇𝑢 ̇𝑣 + 𝐫ᵥᵥ ̇𝑣² }

    𝐚 = aₜ 𝐭 + aₙ 𝐧 ( if aₙ = 0, there is no curvature, planar motion)

    𝐚 ⋅ 𝐧 = aₜ 𝐭 ⋅ 𝐧 + aₙ 𝐧 ⋅ 𝐧
    𝐚 ⋅ 𝐧 = aₜ 0 + aₙ 1 
    (I doubt those who do not understand circular motion,
        may never understand the concept of curvature )
    
    aₙ = 𝐚 ⋅ 𝐧 = { 𝐫ᵤᵤ ̇𝑢²     + 2𝐫ᵤᵥ ̇𝑢 ̇𝑣       + 𝐫ᵥᵥ ̇𝑣² } ⋅ 𝐧
              = (𝐫ᵤᵤ ⋅ 𝐧) ̇𝑢² + 2(𝐫ᵤᵥ ⋅ 𝐧)  ̇𝑢 ̇𝑣  + ( 𝐫ᵥᵥ ⋅ 𝐧)  ̇𝑣² , 𝐧 is unit normal
              =    e  ̇𝑢²    + 2    f  ̇𝑢 ̇𝑣      +      g      𝑣²

     Gauss' Second Fundamental Form (creats curvature):
        e ̇𝑢² + 2 f ̇𝑢 ̇𝑣 + g 𝑣²

    e = 𝐫ᵤᵤ ⋅ 𝐧,
    f = 𝐫ᵤᵥ ⋅ 𝐧,
    g = 𝐫ᵥᵥ ⋅ 𝐧 

    d𝛷d𝑆 = (e g - f²) d𝑢² d𝑣²
    d𝑆² = (E * G - F²) d𝑢² d𝑣²
            
           d𝛷      d𝛷d𝑆     (e g - f²) d𝑢² d𝑣²
    K = ——————— = —————— = ———————————————————————
           d𝑆       d𝑆²      (E * G - F²) d𝑢² d𝑣²

          e g - f²
      = ————————————— (Gaussian Curvature)
          E * G - F²

    d𝛷d𝑆 = (e g - f²) d𝑢² d𝑣²
    
               (e g - f²) d𝑢² d𝑣²
    d𝛷 =  ———————————————————————————
            d𝑆 = √ (E * G - F² )  d𝑢 d𝑣    
       
               (e g - f²) 
    d𝛷  = ————————————————— d𝑢 d𝑣
            √ (E * G - F² )

    For a circle,

    L = 2 π R = 𝜃 R, L is proportional to R
    𝜃 = 2 π (rad)

    For a sphere,

    S = 4 π R² = 𝛷 R², S is proportional to R²

    𝛷 = 4 π (steradian, Solid angle of a sphere)

    Since aₙ ≠ 0 to have curvilinear motion,
    curvature is closely related to "2nd order derivative" of 
    the position vector 𝐫.  
    */

    auto ruu = dif<_u, 2> * r;
    auto rvv = dif<_v, 2> * r;
    auto ruv = dif<_u> * dif<_v> * r;

    /*
        e = 𝐫ᵤᵤ ⋅ 𝐧,
        f = 𝐫ᵤᵥ ⋅ 𝐧,
        g = 𝐫ᵥᵥ ⋅ 𝐧 
    */
    auto e = ruu * n; // 𝐫ᵤᵤ ⋅ 𝐧,
    auto f = ruv * n; // 𝐫ᵤᵥ ⋅ 𝐧,
    auto g = rvv * n; //  𝐫ᵥᵥ ⋅ 𝐧
    
    auto dPhi_dS = e * g - (f^2);
    
    /*
          d𝛷 d𝑆     d𝛷      eg - f²
      K = —————— = ————— = ———————————, Gaussian Curvature
           d𝑆²       d𝑆      EG - F²
    
    */

    auto K = dPhi_dS / dS2; 

                        // 𝑢 (polar angle), 𝑣 (azimutal angle)   
    auto args = make_args( pi / 2,  pi / 2);

    std::cout <<"R = " << R << endl;

    std::cout << "r" << args <<" = " << eval(r, args) << endl; 
    std::cout << "K" << args <<" = " << eval(K, args) << endL; 

    /*                1    1      1      1
       K = k₁ ⋅ k₂ = ———— ———— = ———— = ———— = 0.25 (Curvature of Sphere)
                      R    R      R²     2²
    */
}

int main()
{
    Gmp_DisplayCompilerInfo();

    curvature_of_sphere();
}

