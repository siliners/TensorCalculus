﻿/*
    C++ GMP Library
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary-2025-11-02.zip

    cl ellipsoid.cpp /Fe: m.exe /std:c++latest /EHsc /nologo
    g++ ellipsoid.cpp -o g.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    clang++ ellipsoid.cpp -o c.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    icx-cl ellipsoid.cpp -o i.exe -Qstd=c++23 /nologo

    (SETUP) 가우스 곡률 1, Gaussian Curvature, Differential Geometry
    https://www.youtube.com/watch?v=weTczUZOeXY&list=PLsIvhalfft1Hq4DlHuV2XGk7CDG8GY8nt

*/

#include <gmp/gmp_library.hpp>

using namespace gmp::precision_quadruple;

void solve_arc_length_on_ellipsoidal_surface()
{
    Gmp_DisplayFunctionName();

    auto display_prec = std::numeric_limits<double>::max_digits10;
    
    std::cout << std::setprecision(display_prec);

    std::cout << "Precision: " << display_prec << endL;

    const auto pi = real_type::constant_pi();

    // composable variable
    // t changes from 0 to 1: [0, 1]
    auto t = comvar<1>; 

    auto abc = std::array{ 1_rn, 2_rn, 3_rn };
    auto& [a, b, c] = abc;

    std::cout << "(a, b, c) = " << abc << endl;

    //
    // theta θ: π/2 ⟶ 0, θ is polar angle
    // phi ϕ  : 0 ⟶ π, ϕ is azimuthal angle

    // 1. parametrize the cuve on the ellispoidal surface,
    //    whose semi-axes are a = 1, b = 2, c = 3.

    // 2. compute the arc-length from (θ, ϕ) = (π/2, 0) to (0, π).

    // 1. parametrize the cuve on the ellispoidal surface,
    //    whose semi-axes are a = 1, b = 2, c = 3.

    // Linearization: (t, v) = (0, s) to (1, e)
    // 
    // (a) (e-s)t + s   : operation count 3
    // (b) (1-t)s + e ⋅ t : operation count 4
    // 
    // method (a) is more efficient than (b)

    // (a) (e-s)t + s   : operation count 3
    auto theta // = (0_rn - pi/2) * t + pi/2;
               // = - pi/2 * t + pi/2;
        = pi/2 * (1_rn - t); // θ(𝑡) = π/2 (1 - t)  

    // (a) (e-s)t + s   : operation count 3
    auto phi // = // (pi - 0_rn) * t + 0_rn;
        = pi * t; // ϕ(𝑡) = π t
        
    // 2. we represent the curve on the ellipsoidal surface
    // and transform to the Cartesian coordinates.

    auto r = make_tensor
    ( 
        a * gmm::sin(theta) * gmm::cos(phi), // x-coord
        b * gmm::sin(theta) * gmm::sin(phi), // y-coord
        c * gmm::cos(theta)                  // z-coord
    );

    // r is represented both Cartesian (global coordinates)
    // as well as Scaled Spherical coordinates (local coordinates).

    // 𝕧 = 𝕣 / d 𝑡
    auto v = dif<> * r;

    // ds = √ (|𝕧|²) = √(𝕧 ⋅ 𝕧) d𝑡
    auto ds = gmm::sqrt( v * v );

    // arc-length: ∫ ds = ∫ √(𝕧 ⋅ 𝕧) d𝑡, from 𝑡 = 0 to 𝑡 = 1

    // In itg<0>, 0 represents the parameter t
    // In itg<0>(0_rn, 1_rn), 0_rn represents the initial value of t
    //                        1_rn the terminal value of t, respectively
    // In itg<0>(0_rn, 1_rn) | ds, 
    // the vertical bar | delimits integrand ds
    // Uses default Gaussian Quadrature with 21 segments.
    auto arc_length_default = itg<0>(0_rn, 1_rn) | ds;

    // In itg<0, 7, 1e-30>, 7 represents Gaussian Quadrature's segments,
    //                      1e-30 error tolerance
    // this uses Adaptive Gaussian Quature
    auto arc_length_adapted = itg<0, 7, 1e-30>(0_rn, 1_rn) | ds;

    std::cout << "Arc-length (Default) = " << arc_length_default << endl;
    std::cout << "Arc-length (Adapted) = " << arc_length_adapted << endL;
}

int main()
{
    Gmp_DisplayCompilerInfo();

    solve_arc_length_on_ellipsoidal_surface();
}