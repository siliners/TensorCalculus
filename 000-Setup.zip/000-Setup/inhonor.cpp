﻿/*
    C++ GMP Library
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary-2025-11-02.zip

    최신 GmpLibrary ...
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary.zip

    cl inhonor.cpp /Fe: m.exe /std:c++latest /EHsc /nologo
    g++ inhonor.cpp -o g.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    clang++ inhonor.cpp -o c.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    icx-cl inhonor.cpp -o i.exe -Qstd=c++23 /nologo

    (SETUP) 가우스 곡률 1, Gaussian Curvature, Differential Geometry
    https://www.youtube.com/watch?v=weTczUZOeXY&list=PLsIvhalfft1Hq4DlHuV2XGk7CDG8GY8nt

    공돌이는 풀어도 수학 교수는 절대 못 푸는 문제 - 타원체 상의 곡선, Adaptive Gaussian Quadrature
    https://www.youtube.com/watch?v=iSWu7bXwJCQ&list=PLsIvhalfft1Hq4DlHuV2XGk7CDG8GY8nt

    
    비직교 좌표계, Area Patch on Ellipsoidal Surface, Calculus on Nonorthogonal Coordinates, In Honor of Gauss
    https://www.youtube.com/watch?v=p-ZB6gw5vGQ&t=1078s
    
*/

#include <gmp/gmp_library.hpp>

using namespace gmp::precision_huge;

void surface_area_of_an_ellipsoid(auto&& semi_axes)
{
    Gmp_DisplayFunctionName();

    // auto display_prec = std::numeric_limits<double>::max_digits10;
    std::cout << std::setprecision(display_prec);
    std::cout << "Precision: " << display_prec << endL;

    const auto pi = real_type::constant_pi();

    auto& [a, b, c] = semi_axes;

    std::cout << "(a, b, c) = " << semi_axes << endL;

    enum { _theta, _phi};
    auto [  theta,  phi] = comvar<2>;

    auto r = make_tensor
    (
        a * gmm::sin(theta) * gmm::cos(phi), // x-coord
        b * gmm::sin(theta) * gmm::sin(phi), // y-coord
        c * gmm::cos(theta)                  // z-coord
    );

    //      ∂𝕣
    // 𝕣ₜ = ————
    //      ∂𝜃
    //
    auto rt = dif<_theta> * r;

    //      ∂𝕣
    // 𝕣ₚ = ————
    //      ∂𝜑
    //
    auto rp = dif<_phi> * r;

    // dS = |𝕣ₜ × 𝕣ₚ| d𝜃d𝜑 - Gauss' paper in 1827
    auto dS = (rt % rp).mag();

    // S = ∬ d𝑆, 𝜃: 0 ⟶ π, 𝜑: 0 ⟶ 2 π
    auto S = itg<_theta>(0_rn, pi) * itg<_phi>(0_rn, 2 * pi) | dS;

    // Geometric mean (기하 평균)
    // = (a ⋅ b ⋅ c)^(1/3)
    auto r_g = gmm::pow(a * b * c, 1/3_rn);
    auto G = 4 * pi * (r_g^2);

    std::cout <<"G (Appr'ted) = " << G << endl;
    std::cout <<"S (Computed) = " << S << endl;

    // Arithmetic mean (산술 평균)
    // = (a + b + c)/3
    auto r_a = (a + b + c)/3_rn;
    auto A = 4 * pi * (r_a^2);

    std::cout <<"A (Appr'ted) = " << A << endL;

    std::cout <<"If G <= S <= A is true, \nour computation is valid." << endL;
}

void surface_area_patch_on_an_ellipsoidal_surface(auto&& semi_axes)
{
    Gmp_DisplayFunctionName();

    // auto display_prec = std::numeric_limits<double>::max_digits10;
    std::cout << std::setprecision(display_prec);
    std::cout << "Precision: " << display_prec << endL;

    const auto pi = real_type::constant_pi();

    auto& [a, b, c] = semi_axes;

    std::cout << "(a, b, c) = " << semi_axes << endL;

    enum { _theta, _phi};
    auto [  theta,  phi] = comvar<2>;

    auto r = make_tensor
    (
        a * gmm::sin(theta) * gmm::cos(phi), // x-coord
        b * gmm::sin(theta) * gmm::sin(phi), // y-coord
        c * gmm::cos(theta)                  // z-coord
    );

    //      ∂𝕣
    // 𝕣ₜ = ————
    //      ∂𝜃
    //
    auto rt = dif<_theta> * r;

    //      ∂𝕣
    // 𝕣ₚ = ————
    //      ∂𝜑
    //
    auto rp = dif<_phi> * r;

    // dS = |𝕣ₜ × 𝕣ₚ| d𝜃d𝜑 - Gauss' paper in 1827
    auto dS = (rt % rp).mag();

    auto t = comvar<1>;

    /*
        (𝜃, 𝜑): (0, 0) (north pole) - (π/2 , π)
                 
                 Δ𝜑       π - 0
        𝜑(𝜃) = ————— t = ———————— t = 2 t
                 Δ𝜃       π/2 - 0
    */

    // S = ∬ d𝑆, 𝜃: 0 ⟶ π/2, 𝜑: 0 ⟶ 𝜑(𝜃) = 2 t
    
    // 21 x 21 fixed area differential (Default Gaussian Quadrature)
    auto S1 = itg<_theta>(0_rn, pi/2) * itg<_phi>(0_rn, 2 * t) | dS;

    // In the expression 2 * t, t is a value between 
    // theta 𝜃: 0 ⟶ π/2
   
    std::cout <<"S1 (21 x 21 fixed area differential)    = " << S1 << endl;

    // 41 x 41 fixed area differential (Default Gaussian Quadrature)
    auto S2 = itg<_theta, 41>(0_rn, pi/2) * 
              itg<_phi, 41>(0_rn, 2 * t) | dS;
   
    std::cout <<"S2 (41 x 41 fixed area differential)    = " << S2 << endl;

    // 41 x 21 adaptive area differential (Adaptive Gaussian Quadrature)
    auto S3 = itg<_theta, 41>(0_rn, pi/2) * 
              itg<_phi, 21, 1e-60>(0_rn, 2 * t) | dS;
   
    std::cout <<"S3 (41 x 21 adaptive area differential) = " << S3 << endl;

    // 41 x 41 adaptive area differential (Adaptive Gaussian Quadrature)
    auto S4 = itg<_theta, 41>(0_rn, pi/2) * 
              itg<_phi, 41, 1e-60>(0_rn, 2 * t) | dS;
   
    std::cout <<"S4 (41 x 41 adaptive area differential) = " << S4 << endl;


}

int main()
{
    Gmp_DisplayCompilerInfo();

    // Sphere of radius = 1                    a,     b,    c
    surface_area_of_an_ellipsoid( make_args( 1_rn, 1_rn, 1_rn ) );

    // Ellipsoid with 1, 2, 3 semi-axes respectively
    surface_area_of_an_ellipsoid( make_args( 1_rn, 2_rn, 3_rn ) );

    surface_area_patch_on_an_ellipsoidal_surface
            ( make_args( 1_rn, 2_rn, 3_rn ) );
}