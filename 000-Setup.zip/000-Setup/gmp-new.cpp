﻿/*
    C++ GMP Library
    
    최신 GmpLibrary ...
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary.zip

    cl gmp-new.cpp /Fe: m.exe /std:c++latest /EHsc /nologo
    g++ gmp-new.cpp -o g.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    clang++ gmp-new.cpp -o c.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    icx-cl gmp-new.cpp -o i.exe -Qstd=c++23 /nologo
*/

#include <gmp/gmp_library.hpp>

/*
    Using namespace declaration in global scope is not recommended.
    However, for the sake of simplicity and readability
    in this example, I used using namespace gmp::precision_octuple;
*/

/*
    In C++26 Standard, pack indexing will be supported,
    which allows us to write code like this
    as demonstrated in the current video.
*/

void test_comvar_operatable_functions()
{
    using namespace gmp::precision_octuple;

    Gmp_DisplayFunctionName();

    std::cout<<std::setprecision(display_prec) 
        << "Precision: " << display_prec << endL;

    enum { _x, _y, _z };
    auto [ x,  y,  z] = comvar<3>;

    /*
        comvar<3> declares three variables, x, y, and z,
        which can be used in mathematical expressions.

        comvar stands for "composable variable",
        which is a variable that can be used
        in mathematical expressions and can be evaluated
        with specific values.
    */

    // c is a function of x, y, and z,
    // defined as c = x + y + z
    auto c = x + y + z;

    std::cout << "c = " << eval(c, 1.0, 2.0, 3.0) << endL;

    auto args_c = make_args(3.0, 4, 3.0f);

    std::cout << "args_c = " << args_c << endl;
    std::cout << "c(args_c) = " << eval(c, args_c) << endl;
    std::cout << "c(2, 3, 5) = " << c(2, 3, 5) << endL;

    const auto pi = real_type::constant_pi();

    auto M = make_tensor<3, 3>
    (
        pi * x, 2*pi, 3*pi,
        pi, 5*pi*x*y, 6*pi,
        7*pi, 8*pi, 9*gmm::sin(pi/4 * z)
    );

    auto args_M = make_args(1.0_rn, 2.0_rn, 3.0_rn);
    std::cout << "M = " << eval(M, args_M) << endL;

}

void advanced_comvar_operatable_functions()
{
    using namespace gmp::precision_quadruple;
    
    Gmp_DisplayFunctionName();

    std::cout<<std::setprecision(display_prec) 
        << "Precision: " << display_prec << endL;

    enum { _x, _y, _z };
    auto [ x,  y,  z] = comvar<3>;

    const auto pi = real_type::constant_pi();

    auto M = make_tensor<3, 3, 3>
    (   
        pi * x, 2*pi, 3*pi,
        pi * gmm::cos(x^2), 5*pi*x*y, 6*pi,
        7*pi, 8*pi, 9*gmm::sin(pi/4 * x),

        gmm::cos(x^2) *pi * x, 2*pi, 3*pi,
        pi, 5*pi*x*y, gmm::cos(x^2) *6*pi,
        7*pi, 8*pi, 9*gmm::sin(pi/4 * y),

        pi * x, 2*pi, 3*pi,
        pi, 5*pi*x*y, 6*pi,
        7*pi, 8*pi, 9*gmm::sin(pi/4 * z)
    );

    auto args_M = make_args(1.0_rn, 2.0_rn, 3.0_rn);

    auto m = eval(M, args_M);

    std::cout << "m = " << m 
        <<"\n\ttype of m" >> m << endL;

    auto args_C = make_args(1.0_re + 2.0_im, 2.0_im, 3.0_re + 4.5_im);

    auto c = eval(M, args_C);

    std::cout << "c = " << c 
        <<"\n\ttype of c" >> c << endL;
}

int main()
{
    Gmp_DisplayCompilerInfo();

    test_comvar_operatable_functions();     
    advanced_comvar_operatable_functions();

    return 0;
}

