﻿/*
    C++ GMP Library
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary-2025-11-02.zip

    cl curvature.cpp /Fe: m.exe /std:c++latest /EHsc /nologo
    g++ curvature.cpp -o g.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    clang++ curvature.cpp -o c.exe -std=c++23 -lgmp -lmpfr -lmpc -ltbb12
    icx-cl curvature.cpp -o i.exe -Qstd=c++23 /nologo

    (SETUP) 가우스 곡률 1, Gaussian Curvature, Differential Geometry
    https://www.youtube.com/watch?v=weTczUZOeXY&list=PLsIvhalfft1Hq4DlHuV2XGk7CDG8GY8nt

*/

#include <gmp/gmp_library.hpp>

using namespace gmp::precision_quadruple;

void solve_EXAMPLE_5()
{
    Gmp_DisplayFunctionName();

    auto pi = real_type::constant_pi();

    auto a = 1_rn; // _rn stands for real number
    auto b = 1_rn; 

    // composable variable
    auto t = comvar<1>;

    auto r = // position vector (Curve)
        make_tensor( a * gmm::cos(t), a * gmm::sin(t), b * t);

    //
    //         d𝐫/d𝑡 
    //   𝐓 = ——————————, unit tangent vector
    //         |d𝐫/d𝑡| 
    //  

    // v = d𝐫/d𝑡
    auto dr_dt = dif<> * r; // = dif<0> * r; 

    auto& v = dr_dt; // reference types are alias

    auto args = make_args( pi/4 );

    std::cout << "    r" << args << "=" << eval(r, args) << endl;
    std::cout << "    v" << args << "=" << eval(v, args) << endl;
    std::cout << "dr_dt" << args << "=" << eval(dr_dt, args) << endL;

    auto T = v.unit();

    std::cout << "   T" << args << "=" << eval(T, args) << endl;

    auto T_mag = T.mag();

    std::cout << "T_mag" << args << "=" << eval(T_mag, args) << endl;

    auto dT_dt = dif<> * T; // dT/dt

    std::cout << "dT_dt" << args << "=" << eval(dT_dt, args) << endl;

    auto k = dT_dt.mag() / v.mag();

    std::cout << "    k" << args << "=" << eval(k, args) << endL;

}

int main()
{
    Gmp_DisplayCompilerInfo();

    solve_EXAMPLE_5(); 
}