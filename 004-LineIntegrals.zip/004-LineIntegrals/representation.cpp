﻿/*

    GmpLibrary Latest (Github)
    https://github.com/siliners/GmpLibrary/raw/refs/heads/main/GmpLibrary.zip

    GmpLibrary At the Time of Filming (Github)
    https://github.com/siliners/GmpLibrary/raw/refs/heads/main/GmpLibrary-2026-06-26.zip

    GmpLibrary Latest (talkplayfun.com)
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary.zip

    GmpLibrary At the Time of Filming (talkplayfun.com)
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary-2026-06-26.zip

*/

// Schaum's Outlines, Complex Variables 2nd Edition
// CHAPTER 4 Complex Integration and Cauchy's Theorem 
// Page 133, Problem 4.23

// g++ -std=c++23 -o g.exe representation.cpp -lgmp -lmpfr -lmpc -ltbb12

#include <gmp/gmp_library.hpp>

void complex_representation_1()
{
    Gmp_DisplayFunctionName();

    using namespace gmp::precision_quadruple;

    std::cout << std::setprecision(display_prec);
    std::cout <<"Precision: " << display_prec << endL;

    const auto pi = real_type::constant_pi;
    
    // imaginary unit 𝑖  
    const auto i = 1_im;

    auto x = comvar<1>;
    auto y = (x^3) - 3 * (x^2) + 4 * x - 1;

    // 𝑧 = 𝑥 + 𝑖𝑦 
    auto z = make_cplx(x, y);

    // d𝑧 = d𝑥 + 𝑖 d𝑦 

    // dif<> is a derivative method using 5,7,9-point stencil
    auto dz = dif<> * z;

    auto f = 12 * (z^2) - 4 * i * z;

    std::cout << "x = 1, y = " << eval(y, 1.0_rn) << endl;
    std::cout << "x = 2, y = " << eval(y, 2.0_rn) << endL;

    auto c = itg<>(1_rn, 2_rn) | f * dz;  

    std::cout <<"c = " << c << endL;
}

void complex_representation_2()
{
    Gmp_DisplayFunctionName();

    using namespace gmp::precision_quadruple;

    std::cout << std::setprecision(display_prec);
    std::cout <<"Precision: " << display_prec << endL;

    const auto pi = real_type::constant_pi;
    
    // imaginary unit 𝑖  
    const auto i = 1_im;

    /*
        t: 0 ⟶ 1
        e: eND, s: sTART
        x = (e - s) t + s  (s = 0, x = e t)
          = e t - s t + s
          = s (1 - t) + e t (e = 0, x = s (1 - t))
    */

    auto t = comvar<1>;

    // x: 1 (s) ⟶ 2 (e)
    auto x = (2 - 1) * t + 1;

    // y: 1 (s) ⟶ 3 (e)
    auto y = (3 - 1) * t + 1;

    // 𝑧 = 𝑥 + 𝑖 𝑦 
    auto z = make_cplx(x, y);

    // dft<> is derivative method using FFT
    auto dz = dft<> * z;

    // Analytic function
    // 1. Cauchy-Riemann equations
    // 2. f = u(x, y) + i v(x, y)
    //    ∂f/∂x = ∂f/𝑖∂y - Cauchy-Riemann equations
    //
    // when the integrand 𝑓 is analytic,
    // the contour integral is independent of integration path
    auto f = 12 * (z^2) - 4 * i * z;

    auto c = itg<>(0_rn, 1_rn) | f * dz;

    std::cout <<"c = " << c << endL;
}

int main()
{
    Gmp_DisplayCompilerInfo();

    complex_representation_1();

    complex_representation_2();


    return 0;
}