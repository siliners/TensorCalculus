﻿/*

    GmpLibrary Latest (Github)
    https://github.com/siliners/GmpLibrary/raw/refs/heads/main/GmpLibrary.zip

    GmpLibrary At the Time of Filming (Github)
    https://github.com/siliners/GmpLibrary/raw/refs/heads/main/GmpLibrary-2026-07-03.zip

    GmpLibrary Latest (talkplayfun.com)
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary.zip

    GmpLibrary At the Time of Filming (talkplayfun.com)
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary-2026-07-03.zip

*/

// Schaum's Outlines, Complex Variables 2nd Edition
// CHAPTER 4 Complex Integration and Cauchy's Theorem 
// Page 118 (129), Problem 4.1

// g++ -std=c++23 -o g.exe rline.cpp -lgmp -lmpfr -lmpc -ltbb12

#include <gmp/gmp_library.hpp>

void problem_4_1_a()
{
    Gmp_DisplayFunctionName();

    using namespace gmp::precision_quadruple;

    std::cout << std::setprecision(display_prec);
    std::cout << "Precision: " << display_prec << endL;

    const auto pi = real_type::constant_pi();

    // the parabola 𝑥 = 2𝑡, 𝑦 = 𝑡² + 3
    auto a = []
    {
        auto t = comvar<1>;

        auto x = 2 * t;
        auto y = (t^2) + 3;

        // 𝐅 = P(𝑥,𝑦) 𝕚 + Q(𝑥,𝑦) 𝕛
        // 𝐅 represents physical quantity 
        auto F = make_tensor
        (
            2 * y + (x^2), // P - x component
            3 * x - y  // Q - y component
        );

        // 𝐫 = 𝑥 𝕚 + 𝑦 𝕛 - position vector
        //  describes space
        auto r = make_tensor(x, y);

        // d𝐫 = d𝑥 𝕚 + d𝑦 𝕛 
        auto dr = dft<> * r;

        // ∳ 𝐅 ⋅ d𝐫 
        return itg<>(0_rn, 1_rn) | F * dr;

    }();

    auto ans = 33_rn / 2;
    std::cout << "ans = " << ans << endl;
    std::cout << "(a) = " << a << endL;
}

// (b) straight lines from (0, 3) to (2, 3)
//     and then from (2, 3) to (2, 4)
void problem_4_1_b()
{
    Gmp_DisplayFunctionName();

    using namespace gmp::precision_quadruple;

    std::cout << std::setprecision(display_prec);
    std::cout << "Precision: " << display_prec << endL;

    const auto pi = real_type::constant_pi();

    // (0, 3) ⟶ (2, 3)
    auto b1 = []
    {
        // 𝑥 : 0 ⟶ 2
        auto x = comvar<1>;
        auto y = 3;

        auto F = make_tensor
        (
            2 * y + (x^2), // P - x component
            3 * x - y      // Q - y component
        );

        // 𝐫 = 𝑥 𝕚 + 𝑦 𝕛 
        auto r = make_tensor(x, y);

        // d𝐫 = d𝑥 𝕚 + d𝑦 𝕛 
        auto dr = dft<> * r;

        // dft<> stands for derivative using FFT
        
        // ∳ 𝐅 ⋅ d𝐫 along the contour 𝐫 
        return itg<>(0_rn, 2_rn) | F * dr;

    }();

    // (2, 3) ⟶ (2, 4)
    auto b2 = []
    {
        auto x = 2;

        // 𝑦 : 3 ⟶ 4
        auto y = comvar<1>;

        auto F = make_tensor
        (
            2 * y + (x^2), // P - x component
            3 * x - y      // Q - y component
        );

        // 𝐫 = 𝑥 𝕚 + 𝑦 𝕛 
        auto r = make_tensor(x, y);

        // d𝐫 = d𝑥 𝕚 + d𝑦 𝕛 
        auto dr = dft<> * r;

        // dft<> stands for derivative using FFT
        
        // ∳ 𝐅 ⋅ d𝐫 along the contour 𝐫 
        return itg<>(3_rn, 4_rn) | F * dr;

    }();

    auto ans = 103_rn / 6;
    auto b = b1 + b2;

    std::cout <<"ans = " << ans << endl;
    std::cout <<"(b) = " << b << endL;
}

// (c) a straight line from (0, 3) to (2, 4)
void problem_4_1_c()
{
    Gmp_DisplayFunctionName();

    using namespace gmp::precision_quadruple;

    std::cout << std::setprecision(display_prec);
    std::cout << "Precision: " << display_prec << endL;

    const auto pi = real_type::constant_pi();

    // (0, 3) ⟶ (2, 4)
    auto c = []
    {
        // 𝑡 : 0 ⟶ 1
        auto t = comvar<1>;

        /*
            x = (e - s) t + s (s = 0, convenient)
                e: eEND s: sTART
             
             = s(1-t) + e t (e = 0, convenient)
        */

        // 𝑥 : 0 ⟶ 2
        auto x = 2 * t; // (2 - 0)t + 0

        // 𝑦 : 3 ⟶ 4
        auto y = (4-3) * t + 3;
        
        auto F = make_tensor
        (
            2 * y + (x^2), // P - x component
            3 * x - y      // Q - y component
        );

        // 𝐫 = 𝑥 𝕚 + 𝑦 𝕛 
        auto r = make_tensor(x, y);

        // d𝐫 = d𝑥 𝕚 + d𝑦 𝕛 
        auto dr = dft<> * r;

        // dft<> stands for derivative using FFT
        
        // ∳ 𝐅 ⋅ d𝐫 along the contour 𝐫 
        return itg<>(0_rn, 1_rn) | F * dr;

    }();

    auto ans = 97_rn / 6;
    std::cout <<"ans = " << ans << endl;
    std::cout <<"(c) = " << c << endL;
}

// Schaum's Outlines, Complex Variables 2nd Edition
// CHAPTER 4 Complex Integration and Cauchy's Theorem 
// Page 121 (132), Problem 4.5
//
// Verify Green's theorem, Fig. 4-8
void problem_4_5()
{
    Gmp_DisplayFunctionName();

    using namespace gmp::precision_octuple;

    auto display_prec = 22;

    std::cout << std::setprecision(display_prec);
    std::cout << "Precision: " << display_prec << endL;

    const auto pi = real_type::constant_pi();

    // ∳ 𝐅 ⋅ d𝐫 - Line integral - Tangential form
    auto L = []
    {
        // 𝑦 = 𝑥² 
        auto l1 = []
        {
            // 𝑥: 0 ⟶ 1 
            auto x = comvar<1>;
            auto y = x^2;

            // 𝐫 = 𝑥 𝕚 + 𝑦 𝕛 : 𝑦 = 𝑥² 
            auto r = make_tensor(x, y);

            // d𝐫 = d𝑥 𝕚 + d𝑦 𝕛 
            auto dr = dft<> * r;

            auto F = make_tensor
            (
                2*x*y - (x^2), // P - x component of F
                x + (y^2)      // Q - y component of F
            );

            // ∫ 𝐅 ⋅ d𝐫 along the curve 𝑦 = 𝑥² 
            return itg<>(0_rn , 1_rn) | F * dr;
        }();

        // 𝑦² = 𝑥 
        auto l2 = []
        {
            // 𝑦 : 1 ⟶ 0
            auto y = comvar<1>;
            auto x = y^2;

            auto r = make_tensor(x, y);

            // derivative with 5,7,9-point-stencil
            auto dr = dif<> * r;

             auto F = make_tensor
            (
                2*x*y - (x^2), // P - x component of F
                x + (y^2)      // Q - y component of F
            );

            // ∳ 𝐅 ⋅ d𝐫 
            return itg<>(1_rn, 0_rn) | F * dr;

        }();

        return l1 + l2;
    }();

    // ∬ ∇×𝐅 ⋅ d𝐒
    auto [S_gl, S_gla] = [] 
    {
        // we need TWO independent variables
        // to represent surface
        enum {_x, _y}; 
        // _x and _y are indices
        // to represent x and y
                
        auto [ x,  y] = comvar<2>;

        // 𝐫 represents simple rectangular 
        // xy-plane.
        auto r = make_tensor(x, y);
        
        // 𝐅 represents physical quantity
        // usually it can be velocity field 
        // of a fluid.
        auto F = make_tensor
        (
            2*x*y - (x^2), // P - x component of F
            x + (y^2)      // Q - y component of F
        );

        // d𝐒 = ∂𝐫/∂𝑥 × ∂𝐫/∂𝑦 
        // differential vector area element
        auto dS = ( dif<_x> * r) % (dif<_y> * r);

        // dif<_x> * r = ∂𝐫/∂𝑥
        // dif<_y> * r = ∂𝐫/∂𝑦

        // ∇ × 𝐅 = curl of 𝐅 
        auto curl_F = crl * F;

        // ∬ ∇×𝐅 ⋅ d𝐒 

        // s_gl stands for Surface integral
        // using Gauss-Legendre quadrature

        auto xx = comvar<1>;

        // xx takes a value between [0, 1],
        // the boundary for 𝑥 
        auto s_gl = itg<_x>(0_rn, 1_rn) *
                    itg<_y>(xx^2 /* 𝑦 = 𝑥² */, 
                       gmm::sqrt(xx) /* 𝑦 = √𝑥 */ ) | curl_F * dS;

        // s_gla stands for Surface integral
        // using Gauss-Legendre Adaptive quadrature
         auto s_gla = itg<_x, 21, 1e-22>(0_rn, 1_rn) *
                    itg<_y, 15, 1e-22>(xx^2 /* 𝑦 = 𝑥² */, 
                       gmm::sqrt(xx) /* 𝑦 = √𝑥 */ ) | curl_F * dS;

        return std::tuple{ std::move(s_gl), std::move(s_gla) };

    }();

    auto ans = 1_rn / 30;

    std::cout << "ans   = " << ans << endl;
    std::cout << "L     = " << L << endl;
    std::cout << "S_gl  = " << S_gl << endl;
    std::cout << "S_gla = " << S_gla << endL;

}

int main()
{
    Gmp_DisplayCompilerInfo();

    problem_4_1_a();
    problem_4_1_b();
    problem_4_1_c();

    problem_4_5();

    return 0;
}