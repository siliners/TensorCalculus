﻿/*

    GmpLibrary Latest (Github)
    https://github.com/siliners/GmpLibrary/raw/refs/heads/main/GmpLibrary.zip

    GmpLibrary At the Time of Filming (Github)
    https://github.com/siliners/GmpLibrary/raw/refs/heads/main/GmpLibrary-2026-07-03.zip

    GmpLibrary Latest (talkplayfun.com)
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary.zip

    GmpLibrary At the Time of Filming (talkplayfun.com)
    https://www.talkplayfun.com/sourcecode/gmp/GmpLibrary-2026-07-03.zip

*/

// Schaum's Outlines, Complex Variables 2nd Edition
// CHAPTER 4 Complex Integration and Cauchy's Theorem 
// Page 119 (130), Problem 4.2, 

// g++ -std=c++23 -o g.exe representation.cpp -lgmp -lmpfr -lmpc -ltbb12

#include <gmp/gmp_library.hpp>

// c: 𝑧 = 𝑡² + 𝑖𝑡 
void problem_4_2_a()
{
    Gmp_DisplayFunctionName();

    using namespace gmp::precision_quadruple;

    std::cout << std::setprecision(display_prec);
    std::cout << "Precision: " << display_prec << endL;

    const auto pi = real_type::constant_pi();

    auto a = []
    {
        // 𝑡 : 0 ⟶ 2
        auto t = comvar<1>;
        
        // 𝑧 = 𝑡² + 𝑖 𝑡 
        auto z = make_cplx(t^2, t);

        // dif uses 5,7,9-point stencil
        // d𝑧 = d𝑥 + 𝑖 d𝑦 
        auto dz = dif<> * z;

        // ̅𝑧 = 𝑡² - 𝑖 𝑡 
        auto z_bar = conj(z);

        // ∫ ̅𝑧 d𝑧 along the curve c
        return itg<>( 0_rn, 2_rn) | z_bar * dz;
    }();

    auto ans = 10_re - 8_im / 3_rn;

    std::cout << "ans = " << ans << endl;
    std::cout << "(a) = " << a << endL;
}

// (b) line from 𝑧 = 0 to 𝑧 = 2𝑖
// and then the line from 𝑧 = 2𝑖 to 𝑧 = 4 + 2𝑖.
void problem_4_2_b()
{
    Gmp_DisplayFunctionName();

    using namespace gmp::precision_quadruple;

    std::cout << std::setprecision(display_prec);
    std::cout << "Precision: " << display_prec << endL;

    const auto pi = real_type::constant_pi();

    // contour integral along the line
    // from 𝑧 = 0 to 𝑧 = 2𝑖
    
    auto b_1 =[]
    {
        // 𝑡 : 0 ⟶ 1
        auto t = comvar<1>;

        auto x = 0;   // real part
        auto y = 2*t; // imaginary part

        // 𝑧 = 𝑥 + 𝑖 𝑦 = 0 + 𝑖 2 ⋅ 𝑡 
        auto z = make_cplx(x, y);

        // differentiate z with FFT algorithm
        auto dz = dft<> * z;

        // ̅𝑧 = 𝑥 - 𝑖 𝑦 = 0 - 𝑖 2 ⋅ 𝑡 
        auto z_bar = conj(z);

        return itg<>(0_rn, 1_rn) | z_bar * dz;
    }();

    // contour integral from 𝑧 = 2𝑖 to 𝑧 = 4 + 2𝑖 
    auto b_2 = []
    {
        // 𝑡 : 0 ⟶ 1
        auto t = comvar<1>;

        auto x = 4*t; // real part
        auto y = 2;   // imaginary part

        // 𝑧 = 𝑥 + 𝑖𝑦 - contour or curve
        auto z = make_cplx(x, y);

        // d𝑧 = d𝑥 + 𝑖 d𝑦 
        auto dz = dft<> * z;

        // ̅𝑧 = 𝑥 - 𝑖𝑦
        auto z_bar = conj(z);

        return itg<>(0_rn, 1_rn) | z_bar * dz; 
    }();


    auto ans = 10_re - 8_im;
    auto b = b_1 + b_2;

    std::cout <<"ans = " << ans << endl;
    std::cout <<"(b) = " << b << endL;
}

int main()
{
    Gmp_DisplayCompilerInfo();

    problem_4_2_a();

    problem_4_2_b();

    return 0;
}